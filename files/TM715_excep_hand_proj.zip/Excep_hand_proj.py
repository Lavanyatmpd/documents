#exceptional handling exercise

file=open("Purchase-1.txt","w")
print("Enter file name: ",file.name)
file.write("Chocolate ")
file.write(str(50))
file.write("\n")
file.write("Biscuit ")
file.write(str(35))
file.write("\n")
file.write("Icecream ")
file.write(str(50))
file.write("\n")
file.write("Discount ")
file.write(str(5))
file.close()

numlst=[]
freecount=0
itemcount=0
with open("Purchase-1.txt","r") as f:
    for line in f:
        numlst.append(int(line.split(" ")[1]))
        itemcount=itemcount+1
        if (line.split(" ")[1])=='Free':
            freecount=freecount+1
        elif len(line.strip())==0:
            itemcount+=1
print("Numlist size",len(numlst))
totp=sum(numlst)
payamt=totp-numlst[len(numlst)-1]
print("No of items purchased: ",itemcount-1)
print("No of free items: ",freecount)
print("Amount to pay: ",payamt)
print("Discount given: ",numlst[-1])
print("Final amount paid: ",payamt-numlst[-1])
f.close()