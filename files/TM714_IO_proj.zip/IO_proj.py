#IO operations 
#project 1
def time():
    f=open("C:/Users/91783/Desktop/sample.txt","r")
    countLines=len(f.readlines())
    if 1<=countLines and countLines<=24:
        if countLines>12:
            meettime=countLines-12
            print("Meeting time: {} PM".format(meettime))
        else:
            meettime=countLines
            print("Meeting time: {} AM".format(meettime))
    f.close()

def place():
    f=open("C:/Users/91783/Desktop/sample.txt","r")
    count = 0
    word = ""
    maxCount = 0
    words = []
    for line in f:    
        string = line.lower().replace(',','').replace('.','').split(" ")
        for s in string:  
            words.append(s)
    
    for i in range(0, len(words)):  
        count = 1
        for j in range(i+1, len(words)):  
            if(words[i] == words[j]):  
                count = count + 1
        if(count > maxCount):  
            maxCount = count
            word = words[i] 
    print("Meeting place: {} Street".format(word.capitalize()))
    f.close()

if __name__=='__main__':
    time()
    place()

