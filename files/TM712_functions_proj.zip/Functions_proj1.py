#mini project
#Project 1
def sortarr():
    inparr=[ele for ele in input().split('-')]
    inparr.sort()
    print("-".join(inparr))

sortarr()

#project 2
def checkPalindrome(inpName):
    j=len(inpName)-1
    flag=0
    for ch in inpName:
        if(ch==inpName[j]):
            j=j-1
            flag=1
        else:
            flag=0
            break
    if flag==1:
        print("Yes it is a palindrome")
    else:
        print("No it is not a palindrome")

def vowCount(inpName):
    count=0
    for ch in inpName:
        if(ch=='a' or ch=='e' or ch=='i' or ch=='o' or ch=='u'):
            count=count+1
    print("No of vowels: ",count)

def freqCount(inpName):
    inpdic={}
    for ch in inpName:
        if ch in inpdic:
            inpdic[ch]+=1
        else:
            inpdic[ch]=1
    print(inpdic)

if __name__=='__main__':
    name=input()
    checkPalindrome(name)
    vowCount(name)
    freqCount(name)
